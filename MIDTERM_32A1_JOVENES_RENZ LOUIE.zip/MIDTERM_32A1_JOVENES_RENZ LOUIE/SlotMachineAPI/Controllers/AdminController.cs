using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SlotMachineAPI.DTO;
using SlotMachineAPI.Models;

[Route("api/[controller]")]
[ApiController]
public class AdminsController : ControllerBase
{
	private readonly SlotMachineDbContext _context;

	public AdminsController(SlotMachineDbContext context)
	{
		_context = context;
	}

	[HttpPost("register")]
	public async Task<IActionResult> Register(AdminRegisterDTO dto)
	{
		var existingAdmin = await _context.Admins
			.FirstOrDefaultAsync(a => a.Username == dto.Username);

		if (existingAdmin != null)
		{
			return BadRequest("Username already exists.");
		}

		var admin = new Admin
		{
			Username = dto.Username,
			Password = dto.Password,
			FullName = dto.FullName,
			CreatedAt = DateTime.Now
		};

		_context.Admins.Add(admin);
		await _context.SaveChangesAsync();

		return Ok("Admin registered successfully!");
	}

	[HttpPost("register-player")]
	public async Task<IActionResult> RegisterPlayer([FromBody] PlayerRegisterDTO playerData)
	{
		var player = new Player
		{
			StudentNumber = playerData.StudentNumber,
			FirstName = playerData.FirstName,
			LastName = playerData.LastName,
			CreatedAt = DateTime.Now // Automatically set the creation time
		};

		_context.Players.Add(player);
		await _context.SaveChangesAsync();

		return Ok(new
		{
			studentNumber = player.StudentNumber,
			firstName = player.FirstName,
			lastName = player.LastName,
			createdAt = player.CreatedAt
		});
	}

	[HttpPost("login")]
	public async Task<IActionResult> Login(AdminLoginDto dto)
	{
		var admin = await _context.Admins
			.FirstOrDefaultAsync(a => a.Username == dto.Username && a.Password == dto.Password);

		if (admin == null)
		{
			return Unauthorized("Invalid username or password.");
		}

		return Ok(new
		{
			message = "Login successful!",
			adminId = admin.AdminId,
			fullName = admin.FullName
		});
	}
}
