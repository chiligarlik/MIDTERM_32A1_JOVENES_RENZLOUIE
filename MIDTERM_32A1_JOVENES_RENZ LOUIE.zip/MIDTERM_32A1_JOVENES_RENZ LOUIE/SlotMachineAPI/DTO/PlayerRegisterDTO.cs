﻿using System.ComponentModel.DataAnnotations;
namespace SlotMachineAPI.DTO
{
	public class PlayerRegisterDTO
	{
		[Required]
		[RegularExpression(@"^\d{4}-\d{2}$", ErrorMessage = "StudentNumber must be in the format 2069-22.")]
		public string StudentNumber { get; set; } = string.Empty;

		[Required]
		public string FirstName { get; set; } = string.Empty;

		[Required]
		public string LastName { get; set; } = string.Empty;
	}
}
