﻿using System.ComponentModel.DataAnnotations;

namespace SlotMachineAPI.Models
{
	public class Admin
	{
		public int AdminId { get; set; }

		[Required]
		public string Username { get; set; } = string.Empty;

		[Required]
		public string Password { get; set; } = string.Empty; // ← plain text password

		[Required]
		public string FullName { get; set; } = string.Empty;

		public DateTime CreatedAt { get; set; } = DateTime.Now;
	}
}
